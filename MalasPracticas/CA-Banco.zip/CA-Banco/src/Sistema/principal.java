package Sistema;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class principal {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            List<persona> prestamos = new ArrayList<>();
            double LIMITE_TOTAL = 1_000_000;
            double totalPrestado = 0;
            
            while (true) {
                System.out.print("\n¿Desea registrar un prestamo? (s/n): ");
                if (!sc.nextLine().equalsIgnoreCase("s")) break;
                
                System.out.print("Presione la tecla ENTER para seguir con el proceso");
                boolean completos = sc.nextLine().equalsIgnoreCase("s");
                
                System.out.print("ID: ");
                String id = sc.nextLine();
                System.out.print("Primer nombre: ");
                String nombre = sc.nextLine();
                System.out.print("Primer apellido: ");
                String apellido1 = sc.nextLine();
                System.out.print("Segundo apellido: ");
                String apellido2 = sc.nextLine();
                
                String telCasa = "", telMovil = "";
                if (completos) {
                    System.out.print("Telefono de casa: ");
                    telCasa = sc.nextLine();
                    System.out.print("Telefono móvil: ");
                    telMovil = sc.nextLine();
                }
                
                try {
                    System.out.print("Número de préstamo: ");
                    int numero = Integer.parseInt(sc.nextLine());
                    System.out.print("Valor del préstamo: ");
                    double valor = Double.parseDouble(sc.nextLine());
                    System.out.println("Fecha de autorización (AAAA-MM-DD):");
                    LocalDate fechaAut = LocalDate.parse(sc.nextLine());
                    
                    if (totalPrestado + valor > LIMITE_TOTAL) {
                        System.out.println("Error: se supera el límite total permitido.");
                        continue;
                    }
                    
                    persona prestamo = new persona(numero, valor, fechaAut, id, nombre, apellido1, apellido2);
                    prestamo.setTelefonos(telCasa, telMovil);
                    
                    prestamos.add(prestamo);
                    totalPrestado += valor;
                    
                    System.out.println("\n--- Préstamo registrado correctamente ---");
                    System.out.println(prestamo.mostrarInfo());
                    
                } catch (NumberFormatException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
            
            
            
            System.out.println("\nRegistro finalizado. Total préstamos: " + prestamos.size());
            Menu menu = new Menu();
            menu.setLocationRelativeTo(null);
            menu.setVisible(true);
            
        }
    }
}
