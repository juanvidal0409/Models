package Sistema;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class prestamo {
    protected int numeroPrestamo;
    protected double valor;
    protected LocalDate fechaAutorizacion;
    protected LocalDate fechaEntrega;
    protected List<LocalDate> fechasPago;

    public prestamo(int numeroPrestamo, double valor, LocalDate fechaAutorizacion) {
        if (numeroPrestamo <= 0) throw new IllegalArgumentException("El número de préstamo debe ser mayor a 0.");
        if (valor <= 0) throw new IllegalArgumentException("El valor del préstamo debe ser mayor a 0.");
        if (fechaAutorizacion.getDayOfMonth() > 20)
            throw new IllegalArgumentException("Los préstamos solo se autorizan en los primeros 20 días del mes.");

        this.numeroPrestamo = numeroPrestamo;
        this.valor = valor;
        this.fechaAutorizacion = fechaAutorizacion;
        this.fechaEntrega = fechaAutorizacion.plusDays(7);
        this.fechasPago = calcularFechasPago();
    }

    private List<LocalDate> calcularFechasPago() {
        List<LocalDate> fechas = new ArrayList<>();
        for (int i = 1; i <= 6; i++) {
            fechas.add(fechaEntrega.plusDays(30L * i));
        }
        return fechas;
    }

    public double getValor() {
        return valor;
    }

    public String mostrarInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== PRESTAMO #").append(numeroPrestamo).append(" ===\n");
        sb.append("Valor del préstamo: $").append(valor).append("\n");
        sb.append("Fecha de autorización: ").append(fechaAutorizacion).append("\n");
        sb.append("Fecha tentativa de entrega: ").append(fechaEntrega).append("\n");
        sb.append("Fechas de pago:");
        for (LocalDate fecha : fechasPago) {
            sb.append("\n - ").append(fecha);
        }
        return sb.toString();
    }
}
