package Sistema;


public class CuentaBancaria {
    private static double saldo=10000000.00; //plata inicial
    private static String clave="1234"; //pin secreto
    private static int retiros=0;
    private static int depositos=0;

    public static double getSaldo() {
        
        return saldo; //ver plata
    }

    public static void depositar(double monto) {
        if(monto>0){ //si hay plata
            saldo+=monto; //sumar
            depositos+=1;//Transacciones
            
        }
    }

    public static boolean retirar(double monto) {
        if(monto>0 && monto<=saldo){ //si puedes sacar
            saldo-=monto; //restar
            retiros+=1;//Transacciones
            return true; //sacado
        }
        return false; //no sacado
    }

    public static String getClave() {
        return clave; //ver pin
    }
    
    public static int getRetiros() {
        return retiros; //ver pin
    }
    
    public static int getDepositos() {
        return depositos; //ver pin
    }

    public static boolean cambiarClave(String nuevaClave) {
        if(nuevaClave!=null && nuevaClave.matches("\\d{4}")){ //pin valido (4 numeros)
            clave=nuevaClave; //cambiar pin
            return true; //cambiado
        }
        return false; //no cambiado
    }
    
}