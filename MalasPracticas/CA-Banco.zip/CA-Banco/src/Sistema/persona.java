package Sistema;

import java.time.LocalDate;

public class persona extends prestamo {
    private String id;
    private String nombre;
    private String apellido1;
    private String apellido2;
    private String telCasa;
    private String telMovil;

    public persona(int numeroPrestamo, double valor, LocalDate fechaAutorizacion,
                   String id, String nombre, String apellido1, String apellido2) {
        super(numeroPrestamo, valor, fechaAutorizacion);
        this.id = id;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
    }

    public void setTelefonos(String telCasa, String telMovil) {
        this.telCasa = telCasa;
        this.telMovil = telMovil;
    }

    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public String getApellido1() { return apellido1; }
    public String getApellido2() { return apellido2; }
    public String getTelCasa() { return telCasa; }
    public String getTelMovil() { return telMovil; }

    @Override
    public String mostrarInfo() {
        return "ID: " + id + "\nNombre: " + nombre + " " + apellido1 + " " + apellido2 +
               "\nTel. Casa: " + (telCasa != null ? telCasa : "N/A") +
               "\nTel. Móvil: " + (telMovil != null ? telMovil : "N/A") + "\n" +
               super.mostrarInfo();
    }
}
