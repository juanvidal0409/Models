/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sistema;

import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.UIManager;

/**
 *
 * @author PC
 */
public class Styles {
    private final Color COLOR_FONDO_CLARO = new Color(245, 250, 255);         // Azul muy claro
    private final Color COLOR_BOTON_CLARO = new Color(200, 220, 240);         // Azul claro intermedio
    private final Color COLOR_TEXTO_BOTON_CLARO = new Color(20, 30, 60);      // Azul oscuro para texto
    private final Color COLOR_BORDE_BOTON_CLARO = new Color(150, 180, 210);   // Azul medio

    void aplicarEstiloJOptionPane() {
        UIManager.put("OptionPane.background", COLOR_FONDO_CLARO);
        UIManager.put("Panel.background", COLOR_FONDO_CLARO);
        UIManager.put("OptionPane.messageForeground", COLOR_TEXTO_BOTON_CLARO);
        UIManager.put("Button.background", COLOR_BOTON_CLARO);
        UIManager.put("Button.foreground", COLOR_TEXTO_BOTON_CLARO);
        UIManager.put("Button.border", BorderFactory.createLineBorder(COLOR_BORDE_BOTON_CLARO, 1));
        UIManager.put("Button.focusPainted", false);
        UIManager.put("Button.font", new Font("Segoe UI", Font.PLAIN, 13));
    }

}
